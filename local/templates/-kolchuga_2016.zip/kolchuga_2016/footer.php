<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<? $APPLICATION->IncludeComponent("bitrix:main.include", ".default", array(
    "AREA_FILE_SHOW" => "sect",
    "AREA_FILE_SUFFIX" => "sal",
    "AREA_FILE_RECURSIVE" => "N",
    "EDIT_TEMPLATE" => ""
),
    false,
    array(
        "ACTIVE_COMPONENT" => "Y"
    )
); ?><?

if($curPage == '/'){
    ?><? $APPLICATION->IncludeComponent(
        "bitrix:main.include",
        "",
        Array(
            "AREA_FILE_SHOW" => "file",
            "AREA_FILE_SUFFIX" => "inc",
            "COMPONENT_TEMPLATE" => ".default",
            "EDIT_TEMPLATE" => "",
            "PATH" => SITE_DIR . "en/include_content/footer.php"
        )
    ); ?><?
}
if(strstr($curPage, '/personal/'))
    echo '</div></div>';
?>
<div class="clearfix"></div>
</div><!-- @end static-page -->
</div><!-- @end container -->
</div><!-- @end main__inner -->
<footer class="footer">
    <div class="container">

        <div class="footer__top">
            <div class="footer__top--left">
                <div class="footer__top--header"><?= GetMessage('TITLE_CUSTOMERS') ?></div>
                <div class="footer__top--body js-mh">
                    <? $APPLICATION->IncludeComponent("bitrix:menu", ".default", Array(
                            "ROOT_MENU_TYPE" => "footer_top",
                            "MAX_LEVEL" => "1",
                            "CHILD_MENU_TYPE" => false,
                            "USE_EXT" => "Y",
                            "DELAY" => "N",
                            "ALLOW_MULTI_SELECT" => "N",
                            "MENU_CACHE_TYPE" => "N",
                            "MENU_CACHE_TIME" => "3600",
                            "MENU_CACHE_USE_GROUPS" => "Y",
                            "MENU_CACHE_GET_VARS" => "",
                        )
                    ); ?>
                </div>
            </div>
            <div class="footer__top--right">
                <div class="footer__top--header"><?= GetMessage('TITLE_CONTACTS') ?></div>
                <div class="footer__top--body js-mh">
                    <? $APPLICATION->IncludeComponent(
                        "bitrix:main.include",
                        "",
                        Array(
                            "AREA_FILE_SHOW" => "file",
                            "AREA_FILE_SUFFIX" => "inc",
                            "COMPONENT_TEMPLATE" => ".default",
                            "EDIT_TEMPLATE" => "",
                            "PATH" => SITE_DIR . "/include_content/contacts.php"
                        )
                    ); ?>
                    <? $APPLICATION->IncludeComponent(
                        "bitrix:main.include",
                        "",
                        Array(
                            "AREA_FILE_SHOW" => "file",
                            "AREA_FILE_SUFFIX" => "inc",
                            "COMPONENT_TEMPLATE" => ".default",
                            "EDIT_TEMPLATE" => "",
                            "PATH" => SITE_DIR . "/include_content/social_icons.php"
                        )
                    ); ?>
                </div>
            </div>
        </div>

        <div class="footer__middle">
            <div class="footer__middle--body">
                <? $APPLICATION->IncludeComponent("bitrix:menu", ".default", Array(
                        "ROOT_MENU_TYPE" => "footer_middle",
                        "MAX_LEVEL" => "1",
                        "CHILD_MENU_TYPE" => false,
                        "USE_EXT" => "Y",
                        "DELAY" => "N",
                        "ALLOW_MULTI_SELECT" => "N",
                        "MENU_CACHE_TYPE" => "N",
                        "MENU_CACHE_TIME" => "3600",
                        "MENU_CACHE_USE_GROUPS" => "Y",
                        "MENU_CACHE_GET_VARS" => "",
                    )
                ); ?>
            </div>
        </div>

        <div class="footer__bottom">
            <div class="footer__bottom--left">
                <ul class="footer__bottom-payments">
                    <li><img class="visa" src="<?= SITE_TEMPLATE_PATH ?>/images/icon-visa.svg" alt="Онлайн-оплата банковской картой VISA International"
                             title="Онлайн-оплата банковской картой VISA International" width="56" height="18"></li>
                    <li><img class="mastercard" src="<?= SITE_TEMPLATE_PATH ?>/images/icon-mastercard.svg" alt="Онлайн-оплата банковской картой MasterCard World Wide" 
                             title="Онлайн-оплата банковской картой MasterCard World Wide" width="44" height="26"></li>
                    <li><img class="maestro" src="<?= SITE_TEMPLATE_PATH ?>/images/icon-maestro.svg" alt="Онлайн-оплата банковской картой MasterCard World Wide" 
                             title="Онлайн-оплата банковской картой MasterCard World Wide" width="44" height="26"></li>						
			<!-- li><img class="maestro" src="<?= SITE_TEMPLATE_PATH ?>/images/icon-cash.png" alt="Оплата наличными курьеру и в в пункте самовывоза" 
                             title="Оплата наличными курьеру и в в пункте самовывоза" width="44" height="26"></li>
			<li><img class="maestro" src="<?= SITE_TEMPLATE_PATH ?>/images/icon-payment.png" alt="Оплата по квитанции через любой банк" 
                             title="Оплата по квитанции через любой банк width="44" height="26""></li -->					
                </ul>
            </div>
            <div class="footer__bottom--center">
                <div class="footer__bottom-copyrights">
                    <? $APPLICATION->IncludeComponent(
                        "bitrix:main.include",
                        "",
                        Array(
                            "AREA_FILE_SHOW" => "file",
                            "AREA_FILE_SUFFIX" => "inc",
                            "COMPONENT_TEMPLATE" => ".default",
                            "EDIT_TEMPLATE" => "",
                            "PATH" => SITE_DIR . "include_content/copyrights.php"
                        )
                    ); ?>
                </div>
            </div>
            <div class="footer__bottom--right">
                <div class="footer__bottom-developer">
                    <a href="http://datainlife.ru"><span>Data</span><em>inlife</em></a>
                </div>
                <div class="footer__bottom-counter">
                    <? $APPLICATION->IncludeComponent(
                        "bitrix:main.include",
                        "",
                        Array(
                            "AREA_FILE_SHOW" => "file",
                            "AREA_FILE_SUFFIX" => "inc",
                            "COMPONENT_TEMPLATE" => ".default",
                            "EDIT_TEMPLATE" => "",
                            "PATH" => SITE_DIR . "include_content/counters.php"
                        )
                    ); ?>
                </div>
            </div>
        </div>
    </div>
</footer>
</div><!-- @end main -->
<script>
    (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
        a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-58535221-1', 'auto');
    ga('send', 'pageview');

</script>
<!-- Yandex.Metrika counter -->
<script type="text/javascript"> (function (d, w, c) {
        (w[c] = w[c] || []).push(function () {
            try {
                w.yaCounter36451865 = new Ya.Metrika({
                    id: 36451865,
                    clickmap: true,
                    trackLinks: true,
                    accurateTrackBounce: true,
                    webvisor: true,
                    trackHash: true
                });
            } catch (e) {
            }
        });
        var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () {
            n.parentNode.insertBefore(s, n);
        };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";
        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else {
            f();
        }
    })(document, window, "yandex_metrika_callbacks"); 
</script>
<noscript>
    <div></div>
</noscript><!-- /Yandex.Metrika counter -->

<?

//if(!isset($_COOKIE['consultant_hide'])){
    $APPLICATION->IncludeComponent("bitrix:form.result.new", "consultant", Array(
        "SEF_MODE" => "N",
        "WEB_FORM_ID" => 2,
        "LIST_URL" => "",
        "EDIT_URL" => "",
        "SUCCESS_URL" => "",
        "CHAIN_ITEM_TEXT" => "",
        "CHAIN_ITEM_LINK" => "",
        "IGNORE_CUSTOM_TEMPLATE" => "Y",
        "USE_EXTENDED_ERRORS" => "Y",
        "CACHE_TYPE" => "A",
        "CACHE_TIME" => "3600",
        "SEF_FOLDER" => "/",
        "VARIABLE_ALIASES" => Array()
    ));
//}

?>



</body>
</html>
/**
 * Created by Corndev on 29/06/16.
 */
$(document).ready(function(){
    $("#mmenu").mmenu({
        navbar:{
            title: 'Меню'
        }
    });
});
<?
$MESS["SS_GET_COMPONENT_INFO"] = "Вы можете связать свой профиль с профилями в социальных сетях и сервисах:";
$MESS["SS_NAME"] = "Имя";
$MESS["SS_SOCNET"] = "Социальная сеть";
$MESS["SS_YOUR_ACCOUNTS"] = "Ваши связанные профили:";
$MESS["SS_DELETE"] = "Удалить";
$MESS["SS_PROFILE_DELETE_CONFIRM"] = "Вы уверены, что хотите удалить профиль?";
?>
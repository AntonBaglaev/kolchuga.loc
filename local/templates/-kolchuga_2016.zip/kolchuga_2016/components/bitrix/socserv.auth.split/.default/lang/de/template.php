<?
$MESS["SS_GET_COMPONENT_INFO"] = "Sie kцnnen Ihren Account verlinken mit:";
$MESS["SS_NAME"] = "Name";
$MESS["SS_SOCNET"] = "Soziales Netzwerk";
$MESS["SS_YOUR_ACCOUNTS"] = "Ihre verlinkten Accounts:";
$MESS["SS_DELETE"] = "Lцschen";
$MESS["SS_PROFILE_DELETE_CONFIRM"] = "Mцchten Sie diesen Account wirklich lцschen?";
?>
<?
$MESS["SS_GET_COMPONENT_INFO"] = "You can link your account to:";
$MESS["SS_NAME"] = "Name";
$MESS["SS_SOCNET"] = "Social network";
$MESS["SS_YOUR_ACCOUNTS"] = "Your linked accounts:";
$MESS["SS_DELETE"] = "Delete";
$MESS["SS_PROFILE_DELETE_CONFIRM"] = "Are you sure you want to delete the account?";
?>
<?
$MESS["SS_GET_COMPONENT_INFO"] = "Ви можете пов'язати свій профіль з профілями в соціальних мережах і сервісах:";
$MESS["SS_NAME"] = "Ім'я";
$MESS["SS_SOCNET"] = "Соціальна мережа";
$MESS["SS_YOUR_ACCOUNTS"] = "Ваші пов'язані профілі:";
$MESS["SS_DELETE"] = "Видалити";
$MESS["SS_PROFILE_DELETE_CONFIRM"] = "Ви впевнені, що хочете видалити профіль?";
?>
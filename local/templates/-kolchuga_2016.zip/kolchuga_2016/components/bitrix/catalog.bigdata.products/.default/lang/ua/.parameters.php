<?
$MESS["CVP_LINE_ELEMENT_COUNT"] = "Кількість елементів, що виводяться в одному рядку";
$MESS["CVP_TPL_THEME_BLUE"] = "синя (тема за замовчуванням)";
$MESS["CVP_TPL_THEME_GREEN"] = "зелена";
$MESS["CVP_TPL_THEME_RED"] = "червона";
$MESS["CVP_TPL_THEME_WOOD"] = "дерево";
$MESS["CVP_TPL_THEME_YELLOW"] = "жовта";
$MESS["CVP_TPL_TEMPLATE_THEME"] = "Колірна тема";
$MESS["CVP_TPL_THEME_SITE"] = "Брати тему з налаштувань сайту (для вирішення bitrix.eshop)";
$MESS["LINE_ELEMENT_COUNT_TIP"] = "Кількість елементів, що виводяться в рядку може бути від 1 до 5";
$MESS["CVP_TPL_THEME_BLACK"] = "темна";
?>
<?
$MESS["CVP_LINE_ELEMENT_COUNT"] = "Anzahl der Elemente, die in einer Zeile angezeigt werden";
$MESS["CVP_TPL_THEME_BLUE"] = "Blau (standardmдЯiges Farbschema)";
$MESS["CVP_TPL_THEME_GREEN"] = "Grьn";
$MESS["CVP_TPL_THEME_RED"] = "Rot";
$MESS["CVP_TPL_THEME_WOOD"] = "Holz";
$MESS["CVP_TPL_THEME_YELLOW"] = "Gelb";
$MESS["CVP_TPL_TEMPLATE_THEME"] = "Farbschema";
$MESS["CVP_TPL_THEME_SITE"] = "Farbschema aus den Website-Einstellungen nehmen (fьr die Lцsung bitrix.eshop)";
$MESS["LINE_ELEMENT_COUNT_TIP"] = "Die Anzahl der Elemente pro Zeile kann von 1 bis 5 sein";
$MESS["CVP_TPL_THEME_BLACK"] = "dunkel";
?>
<?
$MESS["CVP_TPL_MESS_RCM"] = "Personal recommendations:";
$MESS["CVP_TPL_ELEMENT_DELETE_CONFIRM"] = "This will delete all the information related to this record! Continue?";
$MESS["CVP_TPL_MESS_BTN_BUY"] = "Buy";
$MESS["CVP_TPL_MESS_BTN_ADD_TO_BASKET"] = "Add to cart";
$MESS["CVP_TPL_MESS_PRODUCT_NOT_AVAILABLE"] = "Out of stock";
$MESS["CVP_TPL_MESS_BTN_DETAIL"] = "Details";
$MESS["CVP_TPL_MESS_BTN_SUBSCRIBE"] = "Subscribe";
$MESS["CVP_CATALOG_SET_BUTTON_BUY"] = "View shopping cart";
$MESS["CVP_ADD_TO_BASKET_OK"] = "Added to your shopping cart";
$MESS["CVP_TPL_MESS_PRICE_SIMPLE_MODE"] = "from #PRICE# for #MEASURE#";
$MESS["CVP_TPL_MESS_MEASURE_SIMPLE_MODE"] = "#VALUE# #UNIT#";
$MESS["CVP_TPL_MESS_BTN_COMPARE"] = "Compare";
$MESS["CVP_CATALOG_TITLE_ERROR"] = "Error";
$MESS["CVP_CATALOG_TITLE_BASKET_PROPS"] = "Item properties to pass to shopping cart";
$MESS["CVP_CATALOG_BASKET_UNKNOWN_ERROR"] = "Unknown error adding an item to shopping cart";
$MESS["CVP_CATALOG_BTN_MESSAGE_CLOSE"] = "Close";
$MESS["CVP_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "View shopping cart";
$MESS["CVP_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "Select";
$MESS["CVP_MSG_YOU_HAVE_NOT_YET"] = "You have not viewed any products yet.";
?>
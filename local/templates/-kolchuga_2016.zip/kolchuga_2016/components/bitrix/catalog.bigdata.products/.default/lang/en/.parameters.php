<?
$MESS["CVP_LINE_ELEMENT_COUNT"] = "Items per row";
$MESS["CVP_TPL_THEME_BLUE"] = "blue (default theme)";
$MESS["CVP_TPL_THEME_GREEN"] = "green";
$MESS["CVP_TPL_THEME_RED"] = "red";
$MESS["CVP_TPL_THEME_WOOD"] = "wood";
$MESS["CVP_TPL_THEME_YELLOW"] = "yellow";
$MESS["CVP_TPL_TEMPLATE_THEME"] = "Color theme";
$MESS["CVP_TPL_THEME_SITE"] = "Use site theme (for bitrix.eshop)";
$MESS["LINE_ELEMENT_COUNT_TIP"] = "Number of items per row can range from 1 to 5";
$MESS["CVP_TPL_THEME_BLACK"] = "dark";
?>
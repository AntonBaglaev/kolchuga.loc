<?
$MESS["AUTH_REGISTER"] = "Registrieren";
$MESS["AUTH_EMAIL_WILL_BE_SENT"] = "An die im Formular angegebene E-Mail Adresse wird eine Anfrage zur Registrierungsbestдtigung gesendet.";
$MESS["AUTH_EMAIL_SENT"] = "An die im Formular angegebene E-Mail Adresse wurde eine Nachricht mit Informationen ьber die Registrierungsbestдtigung gesendet.";
$MESS["AUTH_AUTH"] = "Anmeldung";
$MESS["AUTH_LAST_NAME"] = "Nachname";
$MESS["AUTH_LOGIN_MIN"] = "Login (min. 3 Zeichen)";
$MESS["AUTH_NAME"] = "Name";
$MESS["AUTH_CONFIRM"] = "Passwortbestдtigung";
$MESS["AUTH_PASSWORD_REQ"] = "Passwort";
$MESS["AUTH_REQ"] = "Pflichtfelder.";
$MESS["CAPTCHA_REGF_PROMT"] = "CAPTCHA Code";
$MESS["AUTH_EMAIL"] = "E-Mail";
$MESS["AUTH_SECURE_NOTE"] = "Das Passwort wird verschlьsselt, bevor es versendet wird. So wird das Passwort wдhrend der Ьbertragung nicht offen angezeigt.";
?>
<?
$MESS['BASKET_TITLE'] = "Корзина";
?>
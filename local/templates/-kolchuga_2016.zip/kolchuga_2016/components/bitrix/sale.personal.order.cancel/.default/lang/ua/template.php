<?
$MESS["SALE_RECORDS_LIST"] = "До списку замовлень";
$MESS["SALE_CANCEL_ORDER1"] = "Ви впевнені, що хочете скасувати";
$MESS["SALE_CANCEL_ORDER2"] = "замовлення";
$MESS["SALE_CANCEL_ORDER3"] = "Скасування замовлення необоротне.";
$MESS["SALE_CANCEL_ORDER4"] = "Вкажіть, будь ласка, причину скасування замовлення";
$MESS["SALE_CANCEL_ORDER_BTN"] = "Скасувати замовлення";
?>
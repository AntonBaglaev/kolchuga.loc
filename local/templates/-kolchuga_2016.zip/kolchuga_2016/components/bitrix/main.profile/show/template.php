<?
/**
 * @global CMain $APPLICATION
 * @param array $arParams
 * @param array $arResult
 */
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true)
    die();
?>

<? if($arResult['DATA_SAVED'] == 'Y'){?>
    <div class="alert alert-success"><?= GetMessage('PROFILE_DATA_SAVED') ?></div>
<?}?>
<script type="text/javascript">
    <!--
    var opened_sections = [<?
        $arResult["opened"] = $_COOKIE[$arResult["COOKIE_PREFIX"] . "_user_profile_open"];
        $arResult["opened"] = preg_replace("/[^a-z0-9_,]/i", "", $arResult["opened"]);
        if(strlen($arResult["opened"]) > 0){
            echo "'" . implode("', '", explode(",", $arResult["opened"])) . "'";
        } else{
            $arResult["opened"] = "reg";
            echo "'reg'";
        }
        ?>];
    //-->

    var cookie_prefix = '<?=$arResult["COOKIE_PREFIX"]?>';
</script>
<div class="profile"><? if($arResult["ID"] > 0){ ?>
        <div class="profile--left">

            <table class="table__profile">
                <tr>
                    <th><?= GetMessage('NAME') ?></th>
                    <td><?= $arResult["arUser"]["NAME"] ?></td>
                </tr>
                <tr>
                    <th><?= GetMessage('USER_PHONE') ?></th>
                    <td><?= $arResult['arUser']['PERSONAL_PHONE'] ?></td>
                </tr>
                <tr>
                    <th><?= GetMessage('EMAIL') ?></th>
                    <td><?= $arResult["arUser"]["EMAIL"] ?></td>
                </tr>
                <tr>
                    <th><?= GetMessage('USER_CITY') ?></th>
                    <td><?= $arResult["arUser"]["PERSONAL_CITY"] ?></td>
                </tr>
                <tr>
                    <th><?= GetMessage('USER_STREET') ?></th>
                    <td><?=$arResult["arUser"]["PERSONAL_STREET"]?></td>
                </tr>
                <tr>
                    <td colspan="2" class="text-center">
                        <a href="/personal/profile/edit" class="btn btn-primary">Внести изменения</a>
                    </td>
                </tr>
            </table>

        </div>
        <div class="profile--right">
            <?
            if($arResult["SOCSERV_ENABLED"]){
                $APPLICATION->IncludeComponent("bitrix:socserv.auth.split", "", array(
                    "SHOW_PROFILES" => "Y",
                    "ALLOW_DELETE" => "Y"
                ),
                    false
                );
            }
            ?>
        </div>
    <? } ?>
</div><!-- @end profile -->
<?
$MESS["AUTH_PLEASE_AUTH"] = "Melden Sie sich bitte an";
$MESS["AUTH_LOGIN"] = "Login";
$MESS["AUTH_PASSWORD"] = "Passwort";
$MESS["AUTH_REMEMBER_ME"] = "Passwort merken";
$MESS["AUTH_AUTHORIZE"] = "Anmelden";
$MESS["AUTH_REGISTER"] = "Sich anmelden";
$MESS["AUTH_FIRST_ONE"] = "Wenn Sie die Website zum ersten Mal besuchen, fьllen Sie bitte das Anmeldeformular aus.";
$MESS["AUTH_FORGOT_PASSWORD_2"] = "Passwort vergessen?";
$MESS["AUTH_CAPTCHA_PROMT"] = "Geben Sie den Text vom Bild ein";
$MESS["AUTH_TITLE"] = "Log In";
$MESS["AUTH_SECURE_NOTE"] = "Das Passwort wird verschlьsselt, bevor es versendet wird. So wird das Passwort wдhrend der Ьbertragung nicht offen angezeigt.";
$MESS["AUTH_NONSECURE_NOTE"] = "Das Passwort wird in offener Form versendet. Aktivieren Sie JavaScript  in Ihrem Web-Browser, um das Passwort vor dem Versenden zu verschlьsseln.";
?>
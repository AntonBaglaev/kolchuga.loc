<?php
/**
 * Created by PhpStorm.
 * User: Corndev
 * Date: 10/09/15
 * Time: 15:10
 *
 */?>
<input type="hidden" name="PERSON_TYPE" value="<?=reset($arResult["PERSON_TYPE"])['ID']?>">
<input type="hidden" name="confirmorder" id="confirmorder" value="Y">
<input type="hidden" name="profile_change" id="profile_change" value="N">
<input type="hidden" name="is_ajax_post" id="is_ajax_post" value="Y">
<input type="hidden" name="json" value="Y">
<input type="hidden" name="save" value="Y"/>
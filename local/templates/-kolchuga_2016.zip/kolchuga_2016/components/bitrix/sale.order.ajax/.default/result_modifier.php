<?php
/**
 * Created by PhpStorm.
 * User: Raven
 * Date: 23.12.15
 * Time: 23:19
 */

if(CModule::IncludeModule("iblock")){

    $arResult['STORE_LIST'] = array();

    $res = CIBlockElement::GetList(
        array('sort' => 'asc'),
        array('IBLOCK_ID' => 7, '=PROPERTY_show_in_list_VALUE' => 'Да'),
        false,
        false,
        array('ID', 'IBLOCK_ID', 'NAME')
    );

    while($store = $res->Fetch()){
        $arResult['STORE_LIST'][] = $store;
    }

    $arResult['HAS_UNAVAILABLE'] = false;
    $countUnavailable = 0;
    foreach($arResult['BASKET_ITEMS'] as $key => $item){
        $db_props = CIBlockElement::GetProperty(
            40,
            $item['PRODUCT_ID'],
            array("sort" => "asc"),
            Array("CODE" => 'DOSTUPEN_DLYA_ELEKTRONNOY_OPLATY')
        );

        $arResult['BASKET_ITEMS'][$key]['DOSTUPEN_DLYA_ELEKTRONNOY_OPLATY'] = $db_props->Fetch()['VALUE_XML_ID'];

        if($arResult['BASKET_ITEMS'][$key]['DOSTUPEN_DLYA_ELEKTRONNOY_OPLATY'] !== 'true'){

            $arResult['HAS_UNAVAILABLE'] = true;
            $countUnavailable++;

        }

    }

    if(count($arResult['BASKET_ITEMS']) == $countUnavailable){

        foreach($arResult['PAY_SYSTEM'] as $key => $paysystem){
            if((int)$paysystem['ID'] == 3){

                if($paysystem['CHECKED'] == 'Y'){
                    $arResult['PAY_SYSTEM'][0]['CHECKED'] = 'Y';
                }

                unset($arResult['PAY_SYSTEM'][$key]);
            }
        }
    }

}
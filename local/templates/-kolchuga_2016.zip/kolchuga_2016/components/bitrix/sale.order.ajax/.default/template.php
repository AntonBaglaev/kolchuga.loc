<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$APPLICATION->AddHeadScript(SITE_TEMPLATE_PATH . '/js/autocomplete.js');
$tmp_path = $component->__template->__folder;

// 1.Redirect on submit
include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/helpers/redirect.php"); ?>

<?
// 2.Auth needle
if(!$USER->IsAuthorized() && $arParams["ALLOW_AUTO_REGISTER"] == "N"){
    include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/helpers/need_auth.php");
} else{// 3.Confirm
    if($arResult["USER_VALS"]["CONFIRM_ORDER"] == "Y" || $arResult["NEED_REDIRECT"] == "Y"){
        if(strlen($arResult["REDIRECT_URL"]) == 0)
            include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/parts/confirm.php");
    } else{// 4.Form html
        ?>
        <form class="form__horizontal form__order js-order"
              action="<?= $APPLICATION->GetCurPage(); ?>"
              method="POST"
              name="ORDER_FORM"
              id="ORDER_FORM"
              enctype="multipart/form-data">
            <?//var_dump($_POST)?>
            <input type="hidden" name="is_ajax_post" value="Y">
            <? if($_REQUEST['is_ajax_post'] == 'Y') $APPLICATION->RestartBuffer();
            echo bitrix_sessid_post();
            if($_REQUEST['PERMANENT_MODE_STEPS'] == 1):?>
                <input type="hidden" name="PERMANENT_MODE_STEPS" value="1"/>
            <? endif ?>

            <?// 5.Show errors
            if(!empty($arResult["ERROR"]) && $arResult["USER_VALS"]["FINAL_STEP"] == "Y"){
                include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/helpers/error.php");
            }

            //7. Prepay fields
            if(strlen($arResult["PREPAY_ADIT_FIELDS"]) > 0)
                echo $arResult["PREPAY_ADIT_FIELDS"];

            // 8. Hidden form fields
            include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/helpers/hidden.php");

            //                    foreach($arResult['ORDER_PROP']['USER_PROPS_Y'] as $prop) {
            //                        if ($prop['IS_PHONE'] == 'Y' && $prop['IS_ADDRESS'] == 'Y') continue;
            //                        echo '<input type="hidden" name="'.$prop['FIELD_NAME'].'" value="'.$prop['VALUE'].'">';
            //                    }

            //9. Submit Form
            ?>

            <div class="form__order--wrapper">
                <div class="form__order--left">
                    <div class="form__group--title">
                        Личные данные
                    </div>
                    <? foreach($arResult['ORDER_PROP']['USER_PROPS_Y'] as $key => $prop):
                        if($prop['IS_PHONE'] == 'Y' || $prop['IS_EMAIL'] == 'Y' || $prop['IS_PAYER'] == 'Y'):?>
                            <div class="form__group">
                                <label for="field_11"><?= $prop['NAME'] ?><span class="req">*</span></label>
                                <div class="form__input">
                                    <input id="field_11"
                                           name="<?= $prop['FIELD_NAME'] ?>"
                                           type="text"
                                           value="<?= $prop['VALUE'] ?>">
                                </div>
                            </div>
                            <? unset($arResult['ORDER_PROP']['USER_PROPS_Y'][$key]);
                        endif;
                    endforeach; ?>
                    <div class="form__group--title">
                        Данные для доставки
                    </div>
                    <?
                    $text_location_name = '';
                    $stores_prop = false;

                    foreach($arResult['ORDER_PROP']['USER_PROPS_Y'] as $key => $prop){
                        if($prop['CODE'] == 'CITY'){
                            $text_location_name = $prop['FIELD_NAME'];
                            unset($arResult['ORDER_PROP']['USER_PROPS_Y'][$key]);
                        } elseif($prop['CODE'] == 'PICKUP_POINT'){
                            $stores_prop = $prop;
                            unset($arResult['ORDER_PROP']['USER_PROPS_Y'][$key]);
                        }
                    }

                    foreach($arResult['ORDER_PROP']['USER_PROPS_Y'] as $key => $prop): ?>
                        <div class="form__group">
                            <label for="field_99"><?= $prop['NAME'] ?><span class="req">*</span></label>
                            <div class="form__input">
                                <? if($prop['IS_ADDRESS'] == 'Y'): ?>
                                    <textarea name="<?= $prop['FIELD_NAME'] ?>"
                                              type="text"><?= $prop['VALUE'] ?></textarea>
                                <? elseif($prop['IS_LOCATION'] == 'Y'):

                                    $prop['TEXT_VALUE'] = '';
                                    if($prop['VALUE'] > 0){

                                        $arLocs = CSaleLocation::GetByID($prop['VALUE'], LANGUAGE_ID);

                                        $prop['TEXT_VALUE'] = $arLocs['CITY_NAME'];

                                        if($arLocs["REGION_NAME"]){
                                            $prop['TEXT_VALUE'] .= ", " . $arLocs["REGION_NAME"];
                                        }

                                    }
                                    ?>
                                    <input name="<?= $prop['FIELD_NAME'] ?>"
                                           type="hidden"
                                           value="<?= $prop['VALUE'] ?>">

                                    <input name="<?= $text_location_name ?>"
                                           type="text"
                                           class="search-loc"
                                           autocomplete="off"
                                           value="<?= $prop['TEXT_VALUE'] ?>">
                                    <div class="form__result js-search-result-loc"></div>
                                    <?
                                else: ?>
                                    <input name="<?= $prop['FIELD_NAME'] ?>"
                                           type="text"
                                           value="<?= $prop['VALUE'] ?>">
                                <? endif; ?>
                            </div>
                        </div>
                    <? endforeach; ?>
                    <div class="form__group--title">
                        Дополнительная информация
                    </div>
                    <div class="form__group">
                        <label for="field_88">Комментарий</label>
                        <div class="form__input">
                            <textarea id="field_88"
                                      name="ORDER_DESCRIPTION"
                                      rows="6"
                                      cols="40"><?= $arResult['ORDER_DATA']['ORDER_DESCRIPTION'] ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="form__order--right">
                    <div class="form__group--title">
                        Способы доставки
                    </div>
                    <div class="form__group">
                        <? $current_delivery = 0;
                        foreach($arResult["DELIVERY"] as $delivery_id => $arDelivery):
                            if($delivery_id !== 0 && intval($delivery_id) <= 0):
                                foreach($arDelivery["PROFILES"] as $profile_id => $arProfile):?>
                                    <div class="label__block popover">
                                        <label class="label--radio label--img">
                                            <input type="radio"
                                                   name="<?= htmlspecialcharsbx($arProfile["FIELD_NAME"]) ?>"
                                                   value="<?= $delivery_id . ":" . $profile_id; ?>"
                                                <?= $arProfile["CHECKED"] == "Y" ? "checked=\"checked\"" : ""; ?>
                                            >
                                            <div class="label-inner">
                                                <? if($arProfile['LOGOTIP']): ?>
                                                    <em class="label-icon"><img
                                                            src="<?= $arProfile['LOGOTIP']['SRC'] ?>"
                                                            alt=""></em>
                                                <? endif ?>
                                                <div><span><?= htmlspecialcharsbx($arDelivery["TITLE"]) ?></span></div>

                                            </div>
                                        </label>
                                        <? if($arProfile['DESCRIPTION']): ?>
                                            <span class="label-help"><span class="icon-help-with-circle"></span></span>
                                            <div class="popover-box">
                                                <a href="#" class="popover-close"><i class="icon-close"></i></a>
                                                <?= $arProfile['DESCRIPTION'] ?>
                                            </div>
                                        <? endif ?>
                                    </div>
                                <?endforeach;
                            else:
                                if($arDelivery["CHECKED"] == "Y")
                                    $current_delivery = $arDelivery['ID'];
                                ?>
                                <div class="label__block popover">
                                    <label class="label--radio label--img">
                                        <input type="radio"
                                               name="<?= htmlspecialcharsbx($arDelivery["FIELD_NAME"]) ?>"
                                               value="<?= $delivery_id ?>"
                                            <?= $arDelivery["CHECKED"] == "Y" ? "checked=\"checked\"" : ""; ?>>
                                        <div class="label-inner">
                                            <? if($arDelivery['LOGOTIP']): ?>
                                                <em class="label-icon"><img src="<?= $arDelivery['LOGOTIP']['SRC'] ?>"
                                                                            alt=""></em>
                                            <? endif ?>
                                            <div><span><?= htmlspecialcharsbx($arDelivery["NAME"]) ?></span></div>
                                        </div>
                                    </label>
                                    <? if($arDelivery['DESCRIPTION']): ?>
                                        <span class="label-help"><span class="icon-help-with-circle"></span></span>
                                        <div class="popover-box">
                                            <a href="#" class="popover-close"><i class="icon-close"></i></a>
                                            <?= $arDelivery['DESCRIPTION'] ?>
                                        </div>
                                    <? endif ?>
                                </div>
                            <?endif;
                        endforeach;?>
                    </div><? if($current_delivery == 2 && $stores_prop && count($arResult['STORE_LIST']) > 0): ?>
                        <div class="form__group--title">Выберите пункт самовывоза</div>
                        <div class="form__group"><select name="<?= $stores_prop['FIELD_NAME'] ?>">
                                <? foreach($arResult['STORE_LIST'] as $store): ?>
                                    <option value="<?= $store['NAME'] ?>"<?= $stores_prop['VALUE'] == $store['NAME'] ? ' selected="selected"' : '' ?>><?=
                                        $store['NAME']
                                        ?></option>
                                <? endforeach; ?>
                            </select></div>
                    <? endif ?>
                    <div class="form__group--title">Способы оплаты</div>
                    <div class="form__group">
                        <?$current_paysystem = 0;
                        foreach($arResult['PAY_SYSTEM'] as $paysystem):
                            if($paysystem['CHECKED'] == 'Y')
                                $current_paysystem = $paysystem['ID']?>
                            <div class="label__block popover">
                                <label class="label--radio label--img">
                                    <input type="radio"
                                        <?= $paysystem['CHECKED'] == 'Y' ? 'checked="checked"' : '' ?>
                                           name="PAY_SYSTEM_ID"
                                           value="<?= $paysystem['ID'] ?>">
                                    <div class="label-inner">
                                        <? if($paysystem['PSA_LOGOTIP']['SRC']): ?>
                                            <em class="label-icon">
                                                <img src="<?= $paysystem['PSA_LOGOTIP']['SRC'] ?>"
                                                     alt="<?= $paysystem['NAME'] ?>">
                                            </em>
                                        <? endif ?>
                                        <div><span><?= $paysystem['NAME'] ?></span></div>
                                    </div>
                                </label>
                                <? if($paysystem['DESCRIPTION']): ?>
                                    <span class="label-help"><span class="icon-help-with-circle"></span></span>
                                    <div class="popover-box">
                                        <a href="#" class="popover-close"><i class="icon-close"></i></a>
                                        <?= $paysystem['DESCRIPTION'] ?>
                                    </div>
                                <? endif ?>
                            </div>
                        <? endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="js-order__result">
                <h4>Состав заказа</h4>
                <table class="table table__order-list">
                    <thead>
                    <tr>
                        <th class="td__name">Название</th>
                        <th class="td__price">Цена</th>
                        <th class="td__discount">Скидка</th>
                        <th class="td__price-discount">Цена с учетом скидки</th>
                        <th class="td__number">Кол-во</th>
                        <th class="td__sum">Сумма</th>
                        <th class="td__sum">Online оплата</th>
                    </tr>
                    </thead>
                    <tbody>
                    <? $items_count = 0;
                    $hasUnavailable = false;
                    foreach($arResult['BASKET_ITEMS'] as $item):?>
                        <tr>
                            <td class="td__name">
                                <em>Название</em>
                                <div class="td__inner">
                                    <a href="<?= $item['DETAIL_PAGE_URL'] ?>"><?= $item['~NAME'] ?></a>
                                </div>
                            </td>
                            <td class="td__price">
                                <em>Цена:</em>
                                <div class="td__inner">
                                    <div class="price__block">
                                        <span class="price"><?= $item['BASE_PRICE_FORMATED'] ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="td__discount">
                                <em>Скидка</em>
                                <div class="td__inner">
                                    <div class="price__block">
                                        <span class="discount"><?= $item['DISCOUNT_PRICE_PERCENT_FORMATED'] ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="td__price-discount">
                                <em>Цена с учетом скидки</em>
                                <div class="td__inner">
                                    <div class="price__block">
                                        <span class="price"><?= $item['~PRICE_FORMATED'] ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="td__number">
                                <em>Кол-во:</em>
                                <div class="td__inner">
                                    <span><?= $item['QUANTITY'] ?></span>
                                </div>
                            </td>
                            <td class="td__sum">
                                <em>Сумма:</em>
                                <div class="td__inner">
                                    <div class="td__sum--price">
                                        <span class="price"><?= $item['SUM'] ?></span>
                                    </div>
                                </div>
                            </td>
                            <td class="td__sum">
                                <em>Online оплата:</em>
                                <div class="td__inner"><?=$item['DOSTUPEN_DLYA_ELEKTRONNOY_OPLATY'] == 'true' ?
                                        '<div class="text-success">Да</div>' :
                                        '<div class="text-warning">Нет</div>'?></div>
                            </td>
                        </tr>
                        <? $items_count += $item['QUANTITY'];
                            if(!$hasUnavailable && $item['DOSTUPEN_DLYA_ELEKTRONNOY_OPLATY']){
                                $hasUnavailable = true;
                            }
                    endforeach ?>
                    </tbody>
                </table>
                <?if($hasUnavailable):?>
                <div class="alert alert-warning js-unavailable" <?if($current_paysystem !== '3'){?>style="display: none"<?}?>><?=GetMessage('SOA_HAS_ONLINE_UNAVAILABLE')?></div>
                <?endif?>
                <div class="text-right">
                    <div class="table__total--wrap">
                        <table class="table table__total">
                            <tbody>
                            <tr class="order__sum">
                                <td>Цена без скидки</td>
                                <td><?= $arResult['PRICE_WITHOUT_DISCOUNT'] ?></td>
                            </tr><? if($arResult['PRICE_WITHOUT_DISCOUNT_VALUE'] - $arResult['ORDER_PRICE'] > 0): ?>
                                <tr class="order__discount">
                                <td>Скидка</td>
                                <td><?= number_format($arResult['PRICE_WITHOUT_DISCOUNT_VALUE'] - $arResult['ORDER_PRICE'], 2, '.', ' ') . ' руб' ?></td>
                                </tr><? endif ?>
                            <tr class="order__delivery">
                                <td>Доставка</td>
                                <td><?= $arResult['DELIVERY_PRICE_FORMATED'] ?></td>
                            </tr>
                            <tr class="order__total">
                                <td>Итого</td>
                                <td><?= $arResult['ORDER_TOTAL_PRICE_FORMATED'] ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="order__btn">
                        <a href="#" class="btn btn-primary js-btn-checkout">Оформить заказ</a>
                    </div>
                </div>
            </div>

            <? if($_REQUEST['is_ajax_post'] == 'Y') die(); ?>
        </form>
        <?
    }
}?><p>

</p>
$.fn.makeOrder = function () {

    var _f = $(this);

    _f.on('lock', function(){

        if(_f.hasClass('js-locked')){
            return true;
        }

        _f.addClass('js-locked');

        _f.find('input[type="text"], select, textarea').each(function(){
            $(this).prop('disabled', true);
        });

        _f.find('input[type="radio"], input[type="checkbox"]').iCheck('disable');


        _f.find('.js-btn-checkout').prop('disabled', true).addClass('disabled');

        $('<div class="loader-submit"></div>')
            .prependTo(_f.find('.js-btn-checkout'))
            .parent()
            .css('position', 'relative');
    });

    _f.on('unlock', function(){

        _f.removeClass('js-locked');

        _f.find('input, select, textarea').each(function(){
            $(this).prop('disabled', false);
        });

        _f.find('input[type="radio"], input[type="checkbox"]').iCheck('enable');

        _f.find('.js-btn-checkout')
            .prop('disabled', false)
            .removeClass('disabled')
            .children('.loader-submit')
            .remove();

    });

    //_f.trigger('lock');

    _f.on('paramsChange', function (e) {

        var _c = _f.find('input[name="confirmorder"]');
        _c.val('N');
        _f.trigger('submit');

    });

    _f.on('submit', function (e, no_refresh) {

        if (no_refresh == 'N') {
            _f.find('input[name="is_ajax_post"]').remove();
            return true;
        }

        var f = $(this),
            d = f.serialize(),
            a = f.attr('action');

        _f.trigger('lock');

        $.post(a, d, function (out) {

            _f.trigger('unlock');

            var form_right = $(out).find('.form__order--right').html(),
                form_res = $(out).find('.js-order__result').html();

            f.find('.form__order--right').html(form_right);
            f.find('.js-order__result').html(form_res);

            f.find('input').iCheck();

            f.find('select').selectric({
                arrowButtonMarkup:'<b class="icon-arrow-down"></b>',
                disableOnMobile:false,
                maxHeight:'200'
            });

        });

        e.preventDefault();

    });

    //1.Change profile
    //_f.on('change', 'select', function(){
    //    _f.find('input[name="profile_change"]').val('Y');
    //    _f.trigger('paramsChange');
    //});

    //2.Radio goups
    _f.on('ifClicked', 'input[name="PERSON_TYPE"], input[name="PAY_SYSTEM_ID"], input[name="DELIVERY_ID"]', function (e) {
        var _in = $(this),
            n = _in.attr('name');

        if (n == 'PERSON_TYPE') _f.find('input[name="profile_change"]').val('Y');

        if (n == 'PAY_SYSTEM_ID' && !_in.is(':checked')) {

            _f.find('input[name="PAY_SYSTEM_ID"]:checked').iCheck('uncheck');
            _f.find('input#PAY_CURRENT_ACCOUNT').iCheck('uncheck');
            _in.iCheck('check');

        } else {
            _in.iCheck('check');
        }

        _f.trigger('paramsChange');
    });

    //3.Pay from account
    _f.on('ifClicked', 'input#PAY_CURRENT_ACCOUNT', function (e) {
        $(this).iCheck('toggle');
        $(this).trigger('ifChecked');
        _f.trigger('paramsChange');
    });

    _f.on('ifChecked', 'input#PAY_CURRENT_ACCOUNT', function (e) {
        _f.find('input[name="PAY_SYSTEM_ID"]:checked').iCheck('uncheck');
    });

    _f.on('ifChecked', 'input[name="PAY_SYSTEM_ID"]', function(e){
       parseInt($(this).val()) == 3 ? $('.js-unavailable').show() : $('.js-unavailable').hide();
    });

    _f.on('click', '.control-label', function (e) {
        $(this).next().find('.form-control').focus();
        return false;
    });

    //5.Submit
    _f.on('click', '.js-btn-checkout', function (e) {

        _f.find('input[name="confirmorder"]').val('Y');

        _f.trigger('lock');
        _f.trigger('unlock');

        $.ajax({
            url: _f.attr('action'),
            data: _f.serialize(),
            dataType: 'json',
            type: 'post',
            success: function (out) {
                if (out.redirect) location.href = out.redirect;
            },
            error: function (xhr) {
                var response = xhr.responseText + '';

                /* Test is stupid, but we get result from bitrix core .... */
                if(response.substr(0, 6) == '<input'){
                    _f.trigger('submit');
                }

                return false;
            }
        });

        e.preventDefault();
    });

    //auth or new reg
    _f.on('ifClicked', '.js-new-reg', function (e) {
        if ($(this).val() == 0)
            $('#modal-login').modal('show');
    });

    $('#modal-login').on('hidden.bs.modal', function (e) {
        _f.find('.js-new-reg-true').iCheck('check');
    })

}

$(document).ready(function () {
    $('.js-order').makeOrder();

    $('.search-loc').personalSearch({
        result: '.js-search-result-loc',
        dataProvider: '/local/templates/kolchuga_2016/components/bitrix/sale.order.ajax/.default/helpers/ajax_location.php',
        onSelect: function () {
            var input = $('.search-loc');
            input.val(this.NAME);
            input.prev().val(this.ID);
            input.parents('form').trigger('paramsChange');

        }
    });

    //$('body').on('mouseenter', '.popover', function(){
    //
    //});

    //$('body').on('click', '.popover-close', function(e){
    //
    //    $(this).parents('.hover').removeClass('hover');
    //
    //    return false;
    //    e.preventDefault();
    //});
});
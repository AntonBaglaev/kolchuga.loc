<?php
/**
 * Created by PhpStorm.
 * User: Corndev
 * Date: 10/09/15
 * Time: 15:01
 */
foreach($arResult["ERROR"] as $v):?>
   <?=ShowError($v);?>
<?endforeach?>

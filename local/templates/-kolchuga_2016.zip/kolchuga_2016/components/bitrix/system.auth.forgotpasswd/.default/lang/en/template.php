<?
$MESS ['AUTH_FORGOT_PASSWORD_1'] = "If you forgot your password, enter login or E-Mail<br>Your account info will be sent to you by E-Mail.";
$MESS ['AUTH_GET_CHECK_STRING'] = "Get check string";
$MESS ['AUTH_SEND'] = "Send";
$MESS ['AUTH_AUTH'] = "Authorization";
$MESS ['AUTH_LOGIN'] = "Login:";
$MESS ['AUTH_OR'] = "or";
$MESS ['AUTH_EMAIL'] = "E-Mail:";
?>
<?
$MESS["AUTH_AUTH"] = "Anmeldung";
$MESS["AUTH_GET_CHECK_STRING"] = "Link anfordern";
$MESS["AUTH_FORGOT_PASSWORD_1"] = "Passwort vergessen? Geben Sie Ihren Login oder Ihre E-Mail-Adresse ein.<br />Link zur Passwortдnderung sowie Ihre Registrierungsdaten werden Ihnen per E-Mail gesendet.";
$MESS["AUTH_LOGIN"] = "Login:";
$MESS["AUTH_OR"] = "oder";
$MESS["AUTH_SEND"] = "Senden";
$MESS ['AUTH_EMAIL'] = "E-Mail:";
?>
<?
$MESS["AUTH_OR"] = "або";
$MESS["AUTH_AUTH"] = "Авторизація";
$MESS["AUTH_SEND"] = "Вислати";
$MESS["AUTH_GET_CHECK_STRING"] = "Вислати контрольний рядок";
$MESS["AUTH_LOGIN"] = "Логін:";
$MESS["AUTH_FORGOT_PASSWORD_1"] = "Якщо ви забули пароль, введіть логін або e-mail.<br />Контрольний рядок для зміни пароля, а також ваші реєстраційні дані, будуть вислані вам по e-mail.";
$MESS["AUTH_EMAIL"] = "E-mail:";
?>
<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
<div class="forgot__password">
    <?if($arParams["~AUTH_RESULT"]):?>
        <?= ShowMessage($arParams["~AUTH_RESULT"]); ?>
    <?endif;?>
    <form action="" method="post" target="_top" class="form__horizontal form__forgot">
        <? if(strlen($arResult["BACKURL"]) > 0){ ?>
            <input type="hidden" name="backurl" value="<?= $arResult["BACKURL"] ?>"/>
        <? } ?>
        <input type="hidden" name="AUTH_FORM" value="Y">
        <input type="hidden" name="TYPE" value="SEND_PWD">
        <div class="form__group">
            <label for="field_1">E-mail</label>
            <div class="form__input">
                <input type="text" name="USER_EMAIL" maxlength="255" value=""/>
            </div>
        </div>
        <div class="form__group form__group--nolabel">
            <div class="form__input">
                <input type="submit" name="send_account_info" class="btn btn-primary" value="Выслать">
            </div>
            <div style="text-align: center"><a href="<?= $arResult["AUTH_AUTH_URL"] ?>"><b><?= GetMessage("AUTH_AUTH") ?></b></a></div>
        </div>
    </form>

</div>
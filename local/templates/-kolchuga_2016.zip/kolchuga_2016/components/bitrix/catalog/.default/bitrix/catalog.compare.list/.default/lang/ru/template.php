<?
$MESS ['CATALOG_COMPARE_ELEMENTS'] = "Список сравниваемых элементов";
$MESS ['CATALOG_COMPARE'] = "Сравнить";
$MESS ['CATALOG_DELETE'] = "Убрать";
?>
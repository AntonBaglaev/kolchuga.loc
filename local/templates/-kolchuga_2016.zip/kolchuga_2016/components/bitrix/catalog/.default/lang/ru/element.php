<?
$MESS["CT_TAB_VIEWED"] = "Недавно просмотренные";
$MESS["CT_TAB_SIMILAR"] = "Похожие товары";
?>
<?
$MESS["SEARCH_GO"] = "Шукати";
$MESS["CT_BSP_ADDITIONAL_PARAMS"] = "Додаткові параметри пошуку";
$MESS["CT_BSP_KEYBOARD_WARNING"] = "У запиті \"#query#\" відновлена розкладка клавіатури.";
?>
<?
$MESS["CT_SET_META_SECTION_PAGE"] = " - Страница #NUM#";
?>
<?
$MESS["CT_BCSL_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["SIDEBAR_TITLE"] = "Каталог товаров";
?>
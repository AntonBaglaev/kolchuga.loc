<?
$MESS['BTN_BUY'] = 'Купить';
$MESS['AVAILABLE'] = 'В наличии';
$MESS['NOT_AVAILABLE'] = 'Отсутствует';
$MESS['NEW'] = 'Новинка';
$MESS['HIT'] = 'Хит';
?>
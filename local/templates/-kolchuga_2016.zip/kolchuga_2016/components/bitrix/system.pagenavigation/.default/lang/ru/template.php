<?
$MESS ['nav_of'] = "из";
$MESS ['nav_begin'] = "Начало";
$MESS ['page_prev'] = "Предыдущая";
$MESS ['page_next'] = "Следующая";
$MESS ['nav_end'] = "Конец";
$MESS ['nav_paged'] = "По стр.";
$MESS ['nav_all'] = "Все";
$MESS ['nav_to'] = "-";
$MESS["pages"]="Страницы:";
?>

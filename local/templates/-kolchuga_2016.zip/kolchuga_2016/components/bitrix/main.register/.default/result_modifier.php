<?
foreach ($arResult['SHOW_FIELDS'] as $k=>$fld)
    if ($fld == 'LOGIN') unset($arResult['SHOW_FIELDS'][$k]);
//мы уничтожаем штатное поле LOGIN чтобы заменить его нашим скрытым полем, которое будет с помощью jquery заполняться из поля e-mail
?>
$(document).ready(function() {
    $('.js-login').val($('input[name="REGISTER[EMAIL]"]').val())
});
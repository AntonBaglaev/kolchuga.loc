<?
$MESS["SPOL_CUR_ORDERS"] = "View current orders";
$MESS["SPOL_ORDERS_HISTORY"] = "View order history";
$MESS["SPOL_FROM"] = "from";
$MESS["SPOL_NO_ORDERS"] = "No orders have been found.";
$MESS["SPOL_ORDER"] = "Order";
$MESS["SPOL_ORDER_DETAIL"] = "Order details";
$MESS["SPOL_PAY_SUM"] = "Order total";
$MESS["SPOL_CANCELLED"] = "Canceled";
$MESS["SPOL_PAYSYSTEM"] = "Payment method";
$MESS["SPOL_DELIVERY"] = "Delivery";
$MESS["SPOL_BASKET"] = "Order contents";
$MESS["SPOL_CANCEL_ORDER"] = "Cancel order";
$MESS["SPOL_REPEAT_ORDER"] = "Reorder";
$MESS["SPOL_PAYED"] = "Paid";
$MESS["SPOL_SHT"] = "pcs.";
$MESS["SPOL_STATUS"] = "Orders in status";
$MESS["SPOL_ORDERS_ALL"] = "View all orders";
$MESS["SPOL_YES"] = "Yes";
$MESS["SPOL_NO"] = "No";
$MESS["SPOL_NUM_SIGN"] = "No.";
?>
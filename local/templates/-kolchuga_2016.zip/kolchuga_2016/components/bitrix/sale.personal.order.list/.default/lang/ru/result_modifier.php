<?
$MESS["SPOL_PSEUDO_CANCELLED"] = "Отменён";
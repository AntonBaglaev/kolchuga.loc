<?
$MESS["SPOL_PSEUDO_CANCELLED_COLOR"] = "Колір скасованих замовлень";
$MESS["SPOL_STATUS_COLOR"] = "Колір статусу";
$MESS["SPOL_STATUS_COLOR_GREEN"] = "Зелений";
$MESS["SPOL_STATUS_COLOR_GRAY"] = "Сірий";
$MESS["SPOL_STATUS_COLOR_YELLOW"] = "Жовтий";
$MESS["SPOL_STATUS_COLOR_RED"] = "Червоний";
?>
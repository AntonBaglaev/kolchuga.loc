<?
$MESS["SPOL_PSEUDO_CANCELLED_COLOR"] = "Farbkennzeichnung fьr stornierte Bestellungen";
$MESS["SPOL_STATUS_COLOR"] = "Farbe des Status";
$MESS["SPOL_STATUS_COLOR_GREEN"] = "Grьn";
$MESS["SPOL_STATUS_COLOR_GRAY"] = "Grau";
$MESS["SPOL_STATUS_COLOR_YELLOW"] = "Gelb";
$MESS["SPOL_STATUS_COLOR_RED"] = "Rot";
?>
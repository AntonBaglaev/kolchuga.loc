<?
$MESS["SPOL_CUR_ORDERS"] = "Aktuelle Bestellungen anzeigen";
$MESS["SPOL_ORDERS_HISTORY"] = "Bestell-History anzeigen";
$MESS["SPOL_NO_ORDERS"] = "Es wurden keine Bestellungen gefunden.";
$MESS["SPOL_ORDER"] = "Bestellung";
$MESS["SPOL_ORDER_DETAIL"] = "Details der Bestellung";
$MESS["SPOL_PAY_SUM"] = "Betrag der Bestellung";
$MESS["SPOL_CANCELLED"] = "Storniert";
$MESS["SPOL_PAYSYSTEM"] = "Zahlungsmethode";
$MESS["SPOL_DELIVERY"] = "Lieferung";
$MESS["SPOL_BASKET"] = "Bestellung enthдlt";
$MESS["SPOL_CANCEL_ORDER"] = "Bestellung stornieren";
$MESS["SPOL_REPEAT_ORDER"] = "Erneut bestellen";
$MESS["SPOL_PAYED"] = "Bezahlt";
$MESS["SPOL_SHT"] = "Stьck";
$MESS["SPOL_STATUS"] = "Bestellungen im Status";
$MESS["SPOL_ORDERS_ALL"] = "Alle Bestellungen anzeigen";
$MESS["SPOL_YES"] = "Ja";
$MESS["SPOL_NO"] = "Nein";
$MESS["SPOL_FROM"] = "vom";
$MESS["SPOL_NUM_SIGN"] = "Nr.";
?>
<?
$MESS["SPOL_CUR_ORDERS"] = "Подивитися поточні замовлення";
$MESS["SPOL_ORDERS_HISTORY"] = "Подивитися історію замовлень";
$MESS["SPOL_FROM"] = "від";
$MESS["SPOL_NO_ORDERS"] = "Замовлення не знайдені";
$MESS["SPOL_ORDER"] = "Замовлення";
$MESS["SPOL_ORDER_DETAIL"] = "Детальніше про замовлення";
$MESS["SPOL_PAY_SUM"] = "Сума до оплати";
$MESS["SPOL_CANCELLED"] = "Скасовано";
$MESS["SPOL_PAYSYSTEM"] = "Спосіб оплати";
$MESS["SPOL_DELIVERY"] = "Доставка";
$MESS["SPOL_BASKET"] = "Склад замовлення";
$MESS["SPOL_CANCEL_ORDER"] = "Скасувати замовлення";
$MESS["SPOL_REPEAT_ORDER"] = "Повторити замовлення";
$MESS["SPOL_PAYED"] = "Оплачено";
$MESS["SPOL_SHT"] = "шт.";
$MESS["SPOL_STATUS"] = "Замовлення в статусі";
$MESS["SPOL_ORDERS_ALL"] = "Подивитися всі замовлення";
$MESS["SPOL_YES"] = "Так";
$MESS["SPOL_NO"] = "Ні";
$MESS["SPOL_NUM_SIGN"] = "№";
?>
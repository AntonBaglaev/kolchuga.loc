<?
$MESS["SPOL_PSEUDO_CANCELLED"] = "Storniert";
<?
$MESS["AUTH_PLEASE_AUTH"] = "Пожалуйста, авторизуйтесь:";
$MESS["AUTH_LOGIN"] = "Логин:";
$MESS["AUTH_REMEMBER_SHORT"] = "Запомнить меня";
$MESS["AUTH_PASSWORD"] = "Пароль:";
$MESS["AUTH_LOGIN_BUTTON"] = "Войти";
$MESS["AUTH_REMEMBER_ME"] = "Запомнить меня";
$MESS["AUTH_AUTHORIZE"] = "Войти";
$MESS["AUTH_REGISTER"] = "Регистрация";
$MESS["AUTH_FIRST_ONE"] = "Если вы впервые на сайте, заполните, пожалуйста, регистрационную форму.";
$MESS["AUTH_FORGOT_PASSWORD_2"] = "Забыли пароль?";
$MESS["AUTH_CAPTCHA_PROMT"] = "Введите слово на картинке";
$MESS["AUTH_TITLE_MESS"] = "Вход";
$MESS["AUTH_SECURE_NOTE"]="Перед отправкой формы авторизации пароль будет зашифрован в браузере. Это позволит избежать передачи пароля в открытом виде.";
$MESS["AUTH_NONSECURE_NOTE"]="Пароль будет отправлен в открытом виде. Включите JavaScript в браузере, чтобы зашифровать пароль перед отправкой.";
?>

<?
    $MESS["AUTH_LOGOUT"]="Log out";
?>

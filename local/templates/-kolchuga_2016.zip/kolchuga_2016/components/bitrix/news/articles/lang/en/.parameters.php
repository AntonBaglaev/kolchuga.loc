<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Display element date";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Display element preview picture";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Display element preview text";
$MESS["T_IBLOCK_DESC_NEWS_USE_SHARE"] = "Show Social Network Bookmarks Bar";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_HIDE"] = "Hide Social Network Bookmarks Bar By Default";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_TEMPLATE"] = "Social Network Bookmarks Template";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SYSTEM"] = "Use Social Networks And Bookmarks";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_LOGIN"] = "bit.ly Login";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_KEY"] = "bit.ly Key";
?>
<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use \Bitrix\Main\Localization\Loc;
use \Bitrix\Main\Page\Asset as JsLoader;

Loc::loadLanguageFile(__FILE__);
$curPage = $APPLICATION->GetCurPage();

if(!strstr($curPage, 'en/')){
    $english = true;
}

$GLOBALS['saleFilter'] = array(
    'PROPERTY_AKTSIYA_VALUE' => 'Да'
);

?><!DOCTYPE HTML>
<html lang="ru">
<head>
    <title><? /*Сеть оружейных салонов Кольчуга*/ ?><?if($curPage !== '/'){/*?> - <?*/ $APPLICATION->ShowTitle() ?><?}?></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link type="image/x-icon" href="/favicon.ico" rel="icon">
    <link type="image/x-icon" href="/favicon.ico" rel="shortcut icon">

    <?
    JsLoader::getInstance()->addString("<link href='http://fonts.googleapis.com/css?family=PT+Serif:400,700,400italic,700italic&subset=latin,cyrillic-ext,latin-ext,cyrillic' rel='stylesheet' type='text/css'>");
    JsLoader::getInstance()->addCss(SITE_TEMPLATE_PATH . "/css/fonts.css");
    JsLoader::getInstance()->addCss(SITE_TEMPLATE_PATH . "/css/plugins.css");
    JsLoader::getInstance()->addCss(SITE_TEMPLATE_PATH . "/css/style.css");

    //Js
    JsLoader::getInstance()->addJs(SITE_TEMPLATE_PATH . '/js/jquery.min.js');
    JsLoader::getInstance()->addJs(SITE_TEMPLATE_PATH . '/js/main.min.js');
    JsLoader::getInstance()->addJs(SITE_TEMPLATE_PATH . '/js/custom.js');
    JsLoader::getInstance()->addJs(SITE_TEMPLATE_PATH . '/js/init.js');

    //UI
    JsLoader::GetInstance()->addCss(SITE_TEMPLATE_PATH."/js/ui/jquery-ui.min.css");
    JsLoader::GetInstance()->addJs(SITE_TEMPLATE_PATH."/js/ui/jquery-ui.min.js");

    $APPLICATION->ShowHead();

    ?>
    <!--[if lt IE 10]>
    <script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/fix/placeholder.js"></script>
    <![endif]-->
    <!--[if lt IE 9]>
    <script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/fix/respond.min.js"></script>
    <![endif]-->
    <!--[if (gte IE 6)&(lte IE 8)]>
    <script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/js/fix/selectivizr-min.js"></script>
    <![endif]-->
    <?if($_SERVER['HTTP_HOST'] == 'kolchuga.ru.dev'):?>
    <link rel="stylesheet" href="<?= SITE_TEMPLATE_PATH ?>/css/fonts.css">
    <link rel="stylesheet" href="<?= SITE_TEMPLATE_PATH ?>/css/plugins.css">
    <link rel="stylesheet" href="<?= SITE_TEMPLATE_PATH ?>/css/style.css">
    <?endif?>
    <script>
        //Bigdata fix
        var bx_rcm_adaptive_recommendation_event_attaching = function(){
            return true;
        }
    </script>
</head>

<body>
<div id="panel"><? $APPLICATION->ShowPanel(); ?></div>
<div class="main">
    <? $APPLICATION->IncludeComponent("bitrix:menu", "header_mobile", Array(
            "ROOT_MENU_TYPE" => "top",
            "MAX_LEVEL" => "3",
            "CHILD_MENU_TYPE" => "top_child_mobile",
            "USE_EXT" => "Y",
            "DELAY" => "N",
            "ALLOW_MULTI_SELECT" => "N",
            "MENU_CACHE_TYPE" => "N",
            "MENU_CACHE_TIME" => "3600",
            "MENU_CACHE_USE_GROUPS" => "Y",
            "MENU_CACHE_GET_VARS" => "",
        )
    ); ?>
    <header class="header">
        <div class="container">
            <div class="header__top">
                <div class="header__lang">
                    <a href="/" class="active"><?= GetMessage('TITLE_LANG_RUS') ?></a>
                    <a href="/en/">english</a>
                </div>
                <? $APPLICATION->IncludeComponent("bitrix:system.auth.form", "auth_popup", Array(
                        "REGISTER_URL" => "/register/",
                        "FORGOT_PASSWORD_URL" => "",
                        "PROFILE_URL" => "/personal/profile/",
                        "SHOW_ERRORS" => "Y"
                    )
                ); ?>
            </div>
            <div class="header__middle">
                <div class="header__middle--left">
                    <? $APPLICATION->IncludeComponent("bitrix:menu", "w_icons", Array(
                            "ROOT_MENU_TYPE" => "top_left",
                            "MAX_LEVEL" => "1",
                            "CHILD_MENU_TYPE" => "N",
                            "USE_EXT" => "Y",
                            "DELAY" => "N",
                            "ALLOW_MULTI_SELECT" => "N",
                            "MENU_CACHE_TYPE" => "N",
                            "MENU_CACHE_TIME" => "3600",
                            "MENU_CACHE_USE_GROUPS" => "Y",
                            "MENU_CACHE_GET_VARS" => "",
                        )
                    ); ?>
                </div>
                <div class="header__logo">
                    <a href="/" class="logo"></a>
                </div>
                <div class="header__middle--right">



                    <? $APPLICATION->IncludeComponent("bitrix:sale.basket.basket.small", "", Array(
                            "PATH_TO_BASKET" => "/personal/cart/",
                            "PATH_TO_ORDER" => "/personal/order/make/",
                            "SHOW_DELAY" => "Y",
                            "SHOW_NOTAVAIL" => "Y",
                            "SHOW_SUBSCRIBE" => "N"
                        )
                    ); ?>
                    <div class="header__search">
                        <div class="search-toggle">
                            <span class="icon-search" title="Поиск"></span>
                        </div>
                        <form class="form__search" action="/search/">
                            <input type="text" class="input_inside" name="q" value="" size="15"
                                   placeholder="Поиск по сайту" maxlength="50">
                            <button class="btn__search" type="submit" name="s" title="Найти">
                                <span class="icon-search"></span>
                            </button>
                            <?	$arSearchSection = getSearchSection();
                            $curSearchSection = 0;
                            if(!empty($_REQUEST["section"]) && array_key_exists($_REQUEST["section"],getSearchSection()))
                                $curSearchSection = intval($_REQUEST["section"]);
                            ?>
                            <ul>
                                <li><input type="radio" name="section" value="0" id="section_search_0" <?if(!$curSearchSection):?>checked="checked"<?endif;?> class="no_check"><label for="section_search_0">Везде</label></li>
                                <?foreach($arSearchSection as $key=>$value):?>
                                    <li><input type="radio" name="section" value="<?=$key?>" id="section_search_<?=$key?>" <?if($curSearchSection==$key):?>checked="checked"<?endif;?> class="no_check"><label for="section_search_<?=$key?>"><?=$value?></label></li>
                                <?endforeach;?>
                            </ul>
                            <a class="form__search_close" href=""><span class="icon-close"></span></a>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </header>
    <nav class="navbar" role="navigation">
        <div class="container">
            <? $APPLICATION->IncludeComponent("bitrix:menu", "header", Array(
                    "ROOT_MENU_TYPE" => "top",
                    "MAX_LEVEL" => "2",
                    "CHILD_MENU_TYPE" => "top_child",
                    "USE_EXT" => "Y",
                    "DELAY" => "N",
                    "ALLOW_MULTI_SELECT" => "N",
                    "MENU_CACHE_TYPE" => "N",
                    "MENU_CACHE_TIME" => "3600",
                    "MENU_CACHE_USE_GROUPS" => "Y",
                    "MENU_CACHE_GET_VARS" => "",
                )
            ); ?>
            <? $APPLICATION->IncludeComponent("bitrix:menu", "header_catalog", Array(
                    "ROOT_MENU_TYPE" => "top_child",
                    "MAX_LEVEL" => "1",
                    "CHILD_MENU_TYPE" => "N",
                    "USE_EXT" => "Y",
                    "DELAY" => "N",
                    "ALLOW_MULTI_SELECT" => "N",
                    "MENU_CACHE_TYPE" => "N",
                    "MENU_CACHE_TIME" => "3600",
                    "MENU_CACHE_USE_GROUPS" => "Y",
                    "MENU_CACHE_GET_VARS" => "",
                )
            ); ?>
        </div>
    </nav>

    <div class="main__inner">
        <div class="container">
            <div class="static-page"><?

                if ($curPage !== '/') {
                    ?>
                    <div class="title-page">
                        <h1 class="js-page-title"><? exCSite::ShowH1(); //$APPLICATION->ShowTitle() ?></h1>
                    </div>
                    <?if(strstr($curPage, '/internet_shop/') || CSite::InDir('/search/')) {
						$start_level = 0;
						if(strstr($curPage, '/internet_shop/')) $start_level = 1;
					 $APPLICATION->IncludeComponent(
                        "bitrix:breadcrumb",
                        "",
                        Array(
                            "COMPONENT_TEMPLATE" => ".default",
                            "PATH" => "",
                            "SITE_ID" => "s1",
                            "START_FROM" => $start_level
                        )
                    );}?>
                    <?  
                    /*$APPLICATION->IncludeComponent(
                        "bitrix:breadcrumb",
                        "",
                        Array(
                            "COMPONENT_TEMPLATE" => ".default",
                            "PATH" => "",
                            "SITE_ID" => "s1",
                            "START_FROM" => $start_level
                        )
                    );*/?>
                    <?
                }
                if(strstr($curPage, '/personal/')){
                echo '<div class="personal">';
                ?>
                <? $APPLICATION->IncludeComponent(
                    "bitrix:main.include",
                    "",
                    Array(
                        "AREA_FILE_SHOW" => "file",
                        "AREA_FILE_SUFFIX" => "inc",
                        "COMPONENT_TEMPLATE" => ".default",
                        "EDIT_TEMPLATE" => "",
                        "PATH" => SITE_DIR . "include_content/personal_sidebar.php"
                    )
                ); ?>
                <div class="personal__wrapper">
<? }
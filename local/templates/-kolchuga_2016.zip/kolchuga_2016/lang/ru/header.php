<?
$MESS["TITLE_LANG_RUS"] = "русский";
$MESS["TITLE_CONTACTS"] = 'Контакты';
$MESS["TITLE_CUSTOMERS"] = 'Покупателям';
?>

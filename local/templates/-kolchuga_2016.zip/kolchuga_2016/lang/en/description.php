<?
    $MESS["T_DEFAULT_DESC_NAME"] = "Кольчуга адаптивный шаблон";
    $MESS["T_DEFAULT_DESC_DESC"] = "Адаптивный шаблон для сайта кольчуга";
?>

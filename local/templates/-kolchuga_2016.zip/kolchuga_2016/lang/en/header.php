<?
$MESS["TITLE_LANG_RUS"] = "русский";
$MESS["TITLE_CONTACTS"] = 'Contacts';
$MESS["TITLE_CUSTOMERS"] = 'For customers';
?>
